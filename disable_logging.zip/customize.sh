source $MODPATH/vks/install.sh

ui_print "WARN: Installing this module may cause"
ui_print "bootloop on some devices!"
ui_print " "
ui_print "Please make sure you have a backup"
ui_print "of your data before install."
sleep 3
ui_print " "
ui_print "If you have a copy of the data and want"
ui_print "to continue with the installation,"
ui_print "press volume up (+)..."
ui_print " "
ui_print "Otherwise please abort installation"
ui_print "by pressing volume down (-)..."
if chooseport; then
	ui_print "OK, proceeding..."
else
	exit 1
fi

# Safely stop services
ui_print "[*] Stop logs services..."
echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
stop cnss_diag
stop tcpdump

# Disable WLAN logs
ui_print "[*] Trying to disable WLAN logs..."
rm -rf /data/vendor/wlan_logs
touch /data/vendor/wlan_logs
chmod 000 /data/vendor/wlan_logs

# Disable SELinux logs
ui_print "[*] Disabling SELinux logs..."
echo 0 >/sys/fs/selinux/log/deny_unknown

# Minimize dropbox logs to 1
content insert --uri content://settings/global --bind name:s:dropbox_max_files --bind value:i:1 
settings put global dropbox_max_files 1

ui_print "[!] Installation completed successfully."
ui_print " "
ui_print "[~] Again, please make sure your device"
ui_print "doesn't go into bootloop/fastboot"
ui_print "after installing this module."
ui_print " "
ui_print "*it's not too late to disable it :)*"
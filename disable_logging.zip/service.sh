#!/system/bin/sh
# if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in late_start service mode

# Apply after boot
until [ `getprop sys.boot_completed`. = 1. ]
	    do sleep 1
done

DV=/dev/stune
DC=/dev/cpuset
PS=/proc/sys
SC=/sys/class
SM=/sys/module

# Disable timer migration
write "$KERNEL/timer_migration" 0

# Turn off kernel panic functionality
sysctl -w kernel.panic=0
sysctl -w vm.panic_on_oom=0
sysctl -w kernel.panic_on_oops=0
sysctl -w kernel.softlockup_panic=0
sysctl -w vm.oom_dump_tasks=0
sysctl -w vm.oom_kill_allocating_task=0

# Stop logs
echo "0 0 0 0" > $PS/kernel/printk
echo "off" > $PS/kernel/printk_devkmsg
echo "0" > $PS/debug/exception-trace
echo "0" > $PS/kernel/compat-log

# Disable some scheduler logs/stats, also iostats & reduce latency
# Credits to tytydraco
if [ -e "$KERNEL/sched_schedstats" ]; then
    write "$KERNEL/sched_schedstats" 0
fi
write "$KERNEL/printk" "0        0 0 0"
write "$KERNEL/printk_devkmsg" "off"
for queue in /sys/block/*/queue
do
    write "$queue/iostats" 0
    write "$queue/nr_requests" 64
done

# Stop services
echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
stop cnss_diag
stop tcpdump

# Disable selinux logs
echo 0 >/sys/fs/selinux/log/deny_unknown

# Disabling Scheduler statistics
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0rpmb/queue/iostats
echo "0" > /sys/block/mmcblk1/queue/iostats
echo "0" > /sys/block/loop0/queue/iostats
echo "0" > /sys/block/loop1/queue/iostats
echo "0" > /sys/block/loop2/queue/iostats
echo "0" > /sys/block/loop3/queue/iostats
echo "0" > /sys/block/loop4/queue/iostats
echo "0" > /sys/block/loop5/queue/iostats
echo "0" > /sys/block/loop6/queue/iostats
echo "0" > /sys/block/loop7/queue/iostats
echo "0" > /sys/block/loop8/queue/iostats
echo "0" > /sys/block/loop9/queue/iostats
echo "0" > /sys/block/loop10/queue/iostats
echo "0" > /sys/block/loop11/queue/iostats
echo "0" > /sys/block/loop12/queue/iostats
echo "0" > /sys/block/loop13/queue/iostats
echo "0" > /sys/block/loop14/queue/iostats
echo "0" > /sys/block/loop15/queue/iostats
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable